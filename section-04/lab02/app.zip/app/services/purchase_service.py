from typing import Any

from app.models.purchase_request import PurchaseRequest
from app.repositories.product_repository import ProductRepository
from app.repositories.purchase_repository import PurchaseRepository
from app.schemas.purchase import PurchaseRequestCreate, PurchaseStatusUpdate


class PurchaseNotFoundError(Exception):
    pass


class InvalidStatusTransitionError(Exception):
    pass


class InvalidPurchaseProductError(Exception):
    """구매 요청에 포함된 SKU가 활성 상품 목록에 없을 때 발생합니다."""


class PurchaseService:
    """상품 유효성 검사와 승인 상태 전이 같은 업무 규칙을 담당합니다."""

    def __init__(
        self,
        repository: PurchaseRepository,
        product_repository: ProductRepository,
    ) -> None:
        self.repository = repository
        self.product_repository = product_repository

    def get(self, request_id: int) -> PurchaseRequest:
        purchase = self.repository.get_by_id(request_id)
        if purchase is None:
            raise PurchaseNotFoundError(f"구매 요청 {request_id}을(를) 찾을 수 없습니다.")
        return purchase

    @staticmethod
    def _request_skus(data: PurchaseRequestCreate) -> list[str]:
        """단일 SKU 또는 items/lines 배열 형식에서 요청 SKU를 추출합니다."""
        payload: dict[str, Any]
        if hasattr(data, "model_dump"):
            payload = data.model_dump()
        elif hasattr(data, "dict"):
            # Pydantic v1 호환
            payload = data.dict()
        elif isinstance(data, dict):
            payload = data
        else:
            raise InvalidPurchaseProductError(
                "구매 요청에서 SKU 정보를 읽을 수 없습니다."
            )

        line_items = payload.get("items")
        if line_items is None:
            line_items = payload.get("lines")

        if line_items is not None:
            if not isinstance(line_items, list) or not line_items:
                raise InvalidPurchaseProductError(
                    "구매 요청에는 하나 이상의 상품 항목이 필요합니다."
                )
            skus = [
                str(item.get("sku", "")).strip().upper()
                for item in line_items
                if isinstance(item, dict)
            ]
            if len(skus) != len(line_items) or any(not sku for sku in skus):
                raise InvalidPurchaseProductError(
                    "각 구매 항목에 SKU를 입력해야 합니다."
                )
            return skus

        sku = str(payload.get("sku", "")).strip().upper()
        if not sku:
            raise InvalidPurchaseProductError(
                "구매 요청에 SKU를 입력해야 합니다."
            )
        return [sku]

    def _validate_products(self, data: PurchaseRequestCreate) -> None:
        """모든 SKU가 현재 활성 상품 카탈로그에 등록되어 있는지 확인합니다."""
        for sku in self._request_skus(data):
            # 비활성 상품은 get_active_by_sku에서 조회되지 않아 구매가 거부됩니다.
            product = self.product_repository.get_active_by_sku(sku)
            if product is None:
                raise InvalidPurchaseProductError(
                    f"SKU '{sku}'는 활성 상품 목록에 없습니다."
                )

    def create(self, data: PurchaseRequestCreate) -> PurchaseRequest:
        # 저장 전에 모든 요청 상품을 검증해 미등록/비활성 상품 구매를 차단합니다.
        self._validate_products(data)
        return self.repository.create(data)

    def update_status(
        self, request_id: int, data: PurchaseStatusUpdate
    ) -> PurchaseRequest:
        purchase = self.get(request_id)

        # Orchestrate의 재시도에도 같은 결과를 반환하도록 동일 상태 갱신은 허용합니다.
        if purchase.status == data.status.value:
            return purchase
        if purchase.status != "PENDING":
            raise InvalidStatusTransitionError(
                f"{purchase.status} 상태의 요청은 {data.status.value}(으)로 변경할 수 없습니다."
            )
        return self.repository.update_status(purchase, data)

    def list_all(self) -> list[PurchaseRequest]:
        """구매 승인 요청 전체 목록을 Repository에 위임합니다."""
        return self.repository.list_all()
